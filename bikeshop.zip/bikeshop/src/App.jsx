import React from 'react';
import './App.css';

import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
// import NavDropdown from 'react-bootstrap/NavDropdown';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from './Pages/HomePage';
import AboutUsPage from './Pages/AboutUsPage';
import SingleBikePage from './Pages/SingleBikePage';
import ContactUsPage from './Pages/ContactUsPage';

const NavBarForApp = () => {
  return (
    <Navbar collapseOnSelect bg="dark" variant="dark">
      <Container>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="/home">Home</Nav.Link>
            <Nav.Link href="/about-us">About Us</Nav.Link>
            <Nav.Link href="/contact-us">Contact Us</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  )
}

function App() {
  return (
    <>
      <NavBarForApp />
      <BrowserRouter>
      <Routes>
          <Route path='/home' element={<HomePage />} />
          <Route path='/about-us' element={<AboutUsPage />} />
          <Route path='/single-bike-desc' element={<SingleBikePage />} />
          <Route path='/contact-us' element={<ContactUsPage />} />
      </Routes>
    </BrowserRouter>
    </>
  );
}

export default App;

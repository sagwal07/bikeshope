import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'react-bootstrap';

const BikeCards = ({
    bikeDetails,
}) => {
  const history = useNavigate();
  return (
    <div className='m-2'>
        <Card onClick={e => {
            e.preventDefault();
            history('/single-bike-desc', {state: bikeDetails});
        }}>
            <Card.Img variant="top" src={bikeDetails?.photoLink} />
            <Card.Body>
                <Card.Title>{bikeDetails?.name}</Card.Title>
                <Card.Text>{bikeDetails?.describe}</Card.Text>
                {/* <Button variant="primary">Go somewhere</Button> */}
            </Card.Body>
        </Card>
    </div>
  );
};

export default BikeCards;
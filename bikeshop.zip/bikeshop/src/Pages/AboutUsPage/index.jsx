import React from 'react'
import { Card, Container } from 'react-bootstrap'

const AboutUsPage = () => {
  return (
    <Container>
        <div className='mt-3'>
            <Card className='p-3'>
                <Card className='d-flex justify-content-center align-items-center p-3 mt-2'>
                    <h2>Our mission is to revolutionise personal mobility space</h2>
                </Card>
                <Card className='p-3 mt-2'>
                    <h3>Our Story</h3>
                    <p>
                        It was a visit to the Delhi Auto Expo in January 2008 which spurred two brothers Amit and Anurag Jain to start a venture that would make buying cars easier. The brothers launched cardekho.com in March 2008 from a garrage, Which is worth a claimed $360 million today.
                    </p>
                </Card>
                <Card className='p-3 mt-2'>
                    <h3>Building the ecosystem for Buyers and Seller</h3>
                    <p>
                    Our vision is to construct a complete ecosystem for consumers and car manufacturers, dealers and related businesses such that consumers have easy and complete access to not only buying and selling cars, but also manage their entire ownership experience, be it accessories, tyres, batteries, insurance or roadside assistance.
                    </p>
                </Card>
            </Card>
        </div>
    </Container>
  )
}

export default AboutUsPage
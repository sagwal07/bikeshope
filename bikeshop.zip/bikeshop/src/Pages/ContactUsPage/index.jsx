import React from 'react'
import { Card, Container } from 'react-bootstrap'

const ContactUsPage = () => {
  return (
    <Container>
        <div className='mt-3'>
            <Card>
                <Card.Header>
                    Contact Us
                </Card.Header>
                <Card.Body>
                    <p>
                        <strong>Mobile No. :</strong> 9999999991
                    </p>
                    <p>
                        <strong>Email ID :</strong> abc@bikeshop.com
                    </p>
                    <p>
                        <strong>Address :</strong> Chandigarh
                    </p>
                </Card.Body>
            </Card>
        </div>
    </Container>
  )
}

export default ContactUsPage
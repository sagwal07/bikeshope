import React from 'react';
import { Card, Container } from 'react-bootstrap';
import BikeCards from '../../Components/BikeCards';
import Bikes from '../../Data/bikes';

const HomePage = () => {
  return (
    <Container>
        <div className='mt-3'>
            <Card>
                <Card.Body>
                    <div className='p-2'>
                        <div className='row'>
                            {Bikes?.map(bikeDetails => {
                                return (
                                    <div className='col-md-4'>
                                        <BikeCards bikeDetails={bikeDetails} />
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                </Card.Body>
            </Card>
        </div>
    </Container>
  );
};

export default HomePage;
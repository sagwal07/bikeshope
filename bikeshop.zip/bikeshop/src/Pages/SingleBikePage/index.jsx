/* eslint-disable jsx-a11y/alt-text */
import React from 'react';
import { Card, Container } from 'react-bootstrap';
import { useLocation } from 'react-router-dom';

const SingleBikePage = () => {
  const location = useLocation();

  return (
    <Container>
        <div className='mt-3'>
            <Card className='p-4'>
                <div >
                    <img src={location?.state?.photoLink} />
                </div>
                <h1>{location?.state?.name}</h1>
                <h4>{location?.state?.describe}</h4>
            </Card>
        </div>
    </Container>
  )
}

export default SingleBikePage